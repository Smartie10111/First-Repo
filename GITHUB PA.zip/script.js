// Stand-in for your script.js: time-based greeting + animated tile background
(function () {
  var h = new Date().getHours();
  var g = h < 12 ? "Good morning" : h < 18 ? "Good afternoon" : "Good evening";
  var el = document.getElementById("greeting");
  if (el) el.textContent = g;

  var field = document.getElementById("tileField");
  if (!field) return;
  var count = 300, tiles = [];
  for (var i = 0; i < count; i++) {
    var s = document.createElement("span");
    field.appendChild(s);
    tiles.push(s);
  }
  if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  setInterval(function () {
    var t = tiles[Math.floor(Math.random() * tiles.length)];
    var cls = Math.random() > .5 ? "on" : "on2";
    t.classList.add(cls);
    setTimeout(function () { t.classList.remove(cls); }, 900);
  }, 120);
})();
